package spider;
//import spider.crawler;
import java.io.*;
import java.util.*;
import java.io.DataInputStream;
import java.io.File;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.BufferedInputStream;
import java.io.IOException;
 /* @author hsaeed.bscs13seecs
 */
public class Spider {

    public int hasWord(File file, String word)
    {  int count = 0;
        try {
      
      
     Scanner scanner = new Scanner(file);
     while (scanner.hasNextLine()) {
     Scanner s2 = new Scanner(scanner.nextLine());
     while (s2.hasNext()) {
            String s = s2.next();
            if (s.equalsIgnoreCase(word))
            {count++;
            break;
            }
            
          
        }
    
}
  
      // dispose all the resources after using them.
     
 
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    
    }
    return count;
    }
    
    
     public static void main(String[] args) {
    Spider lab = new Spider();
        String word = "Advance";
       
      
  crawler crawler = new crawler();
  List<File> files = crawler.crawl("C:\\Users\\hsaeed.bscs13seecs\\Desktop\\spider\\", 2);
    
    for(File file1: files)
    {
        
         String ext = getFileExtension(file1);
         if("txt".equals(ext))
         {
            int num = lab.hasWord(file1,word);
            if(num>0)
             {
           
                System.out.println("Word is found in "+file1.getName());
               }
         }
    }


 
    
  }

    /**
     * @param args the command line arguments
     */
  private static String getFileExtension(File file) {
        String fileName = file.getName();
        if(fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
        return fileName.substring(fileName.lastIndexOf(".")+1);
        else return "";
    }
    
}
