package spider;

/**
 *
 * @author hsaeed.bscs13seecs
 */
import java.io.*;
import java.util.*;


public class crawler
{
   public List<File> crawl(String path, int depth)
   {
      List<File> fileList = new ArrayList<File>();
      
      if(depth > 0)
      {
        File directory = new File(path);

        //get all the files from a directory

        File[] fList = directory.listFiles();
        if(fList.length > 0)
          for(File file: fList)
          {
            fileList.add(file);
          }
        
        File _file = new File(path);
        String[] directories = _file.list(new FilenameFilter() {
          @Override
          public boolean accept(File current, String name) {
            return new File(current, name).isDirectory();
          }
        });
        
        for(String dir: directories)
        {
          List<File> nextList = crawl(path + dir + "\\", depth - 1);
          
          for(File file: nextList)
          {
            fileList.add(file);
          }
        }
      }
      return fileList;
   }
}